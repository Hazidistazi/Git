# QT5AlbumBrowsers
This is a QT5 - based album browser
![Image text](https://github.com/impressJay/QT5AlbumBrowsers/raw/master/QT5xiangce.png)
